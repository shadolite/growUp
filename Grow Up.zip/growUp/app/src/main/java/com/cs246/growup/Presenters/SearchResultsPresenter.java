package com.cs246.growup.Presenters;

import java.util.ArrayList;

public class SearchResultsPresenter {
    //private SearchResults searchResults;
    private ArrayList<String> searchResults;

    public void searchTerm(String term){

    }
}
