package com.cs246.growup.Models;

public enum Tag {
    Physical,
    Spiritual,
    Intellectual,
    Social
}