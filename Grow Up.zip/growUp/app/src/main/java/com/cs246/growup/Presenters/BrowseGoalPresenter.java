package com.cs246.growup.Presenters;

public class BrowseGoalPresenter {
}
