package com.cs246.growup.Views;

import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class SearchResultsView extends AppCompatActivity {
    public void onCreate() {}
    public View onCreateView() {return null;}

    //only needed if we need to override the onStop() method included with AppCompatActivity
    public void onStop() {
        super.onStop();
    }
    public void notifyDataReady() {}
    public void notifyConfigChanged() {}

}
