package com.cs246.growup.Models;

public class Config {
    int type;
    public void readConfig(){}
    public void saveConfig(){}
}
