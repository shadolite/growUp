package com.cs246.growup.Presenters;

import com.cs246.growup.Models.Entry;

public class AddEntryPresenter {

    public Entry entry;

    public void setEntryDate(){

    }

    public void addNewItem(){

    }
}
