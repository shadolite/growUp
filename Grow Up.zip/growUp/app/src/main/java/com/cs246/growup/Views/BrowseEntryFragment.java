package com.cs246.growup.Views;

public class BrowseEntryFragment extends BrowseFragment {
}
