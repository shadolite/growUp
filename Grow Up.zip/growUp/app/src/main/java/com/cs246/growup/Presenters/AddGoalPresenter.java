package com.cs246.growup.Presenters;

import com.cs246.growup.Models.Goal;

public class AddGoalPresenter {

    public Goal goal;

    public void setTags(){

    }

    public void setTitle(){

    }

    public void setDescription(){

    }

    public void setDueDate(){

    }
}
