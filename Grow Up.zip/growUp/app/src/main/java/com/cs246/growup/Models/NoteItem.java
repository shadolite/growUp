package com.cs246.growup.Models;

public class NoteItem extends Item {
    public String body;

    public NoteItem(String title) {
        super(title);
    }
}
