package com.cs246.growup.Views;

public class BrowseGoalFragment extends BrowseFragment {
}
